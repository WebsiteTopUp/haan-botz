<?php

$namafile = 'Vidio Virall 2022'; // Nama File

$ukuran = '9,97MB'; //Ukuran file

$file = 'https://pomf2.lain.la/f/6b954blm.mp4'; // link mediafire asli/redirect

?>